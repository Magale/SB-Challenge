package com.example.security;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import java.util.Date;
import java.util.Base64;
import java.nio.charset.StandardCharsets;

// Utility class for generating JWT tokens securely
public class JWTUtil {
    // Secret key should be securely stored and retrieved from environment variables or a config file
    private static final String SECRET_KEY = Base64.getEncoder().encodeToString("secret".getBytes(StandardCharsets.UTF_8));

    // Generates a JWT token for the given username with a 1-hour expiration time
    public static String generateToken(String username) {
        return Jwts.builder()
                .setSubject(username) // Sets the subject of the token to the username
                .setIssuedAt(new Date()) // Sets the token's issuance time
                .setExpiration(new Date(System.currentTimeMillis() + 1000 * 60 * 60)) // Sets expiration time to 1 hour
                .signWith(SignatureAlgorithm.HS256, SECRET_KEY) // Signs the token with the secret key using HS256 algorithm
                .compact(); // Builds and returns the token as a compact string
    }
}
