package com.example.rest;

import jakarta.ws.rs.ApplicationPath;
import jakarta.ws.rs.core.Application;

// Defines the base URI for all REST endpoints in this application
@ApplicationPath("/api")
public class RestApplication extends Application {
    // This class activates JAX-RS and sets the root path for the REST API
}

