package com.example.rest;

import com.example.dao.UserDAO;
import com.example.model.User;
import jakarta.inject.Inject;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;

// Defines a REST resource for user-related operations
@Path("/users")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class UserResource {

    @Inject // Injects an instance of UserDAO for database interactions
    private UserDAO userDAO;

    // Handles HTTP POST request to create a new user
    @POST
    public Response createUser(User user) {
        userDAO.saveUser(user); // Saves the user to the database
        return Response.status(Response.Status.CREATED).entity(user).build(); // Returns 201 Created response
    }

    // Handles HTTP GET request to retrieve all users
    @GET
    public List<User> getUsers() {
        return userDAO.findAllUsers(); // Retrieves and returns all users from the database
    }

    // Handles HTTP GET request to retrieve a user by ID
    @GET
    @Path("/{id}")
    public Response getUserById(@PathParam("id") Long id) {
        User user = userDAO.findUserById(id); // Searches for the user by ID
        if (user == null) {
            return Response.status(Response.Status.NOT_FOUND).build(); // Returns 404 Not Found if user doesn't exist
        }
        return Response.ok(user).build(); // Returns the user if found
    }

    // Handles HTTP PUT request to update an existing user by ID
    @PUT
    @Path("/{id}")
    public Response updateUser(@PathParam("id") Long id, User updatedUser) {
        User existingUser = userDAO.findUserById(id); // Finds the user by ID
        if (existingUser == null) {
            return Response.status(Response.Status.NOT_FOUND).build(); // Returns 404 Not Found if user doesn't exist
        }
        existingUser.setName(updatedUser.getName()); // Updates the name
        existingUser.setEmail(updatedUser.getEmail()); // Updates the email
        userDAO.updateUser(existingUser); // Saves the updated user
        return Response.ok(existingUser).build(); // Returns the updated user
    }

    // Handles HTTP DELETE request to remove a user by ID
    @DELETE
    @Path("/{id}")
    public Response deleteUser(@PathParam("id") Long id) {
        userDAO.deleteUser(id); // Deletes the user from the database
        return Response.noContent().build(); // Returns 204 No Content to indicate successful deletion
    }
}

