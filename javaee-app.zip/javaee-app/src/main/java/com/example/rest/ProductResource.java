package com.example.resources;

import com.example.dao.ProductDAO;
import com.example.model.Product;
import jakarta.enterprise.context.RequestScoped; // Marks this as a request-scoped bean
import jakarta.inject.Inject; // Used to inject dependencies
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.ws.rs.*; // JAX-RS annotations for RESTful web services
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;

@Path("/products") // Base URL for this resource: /api/products
@RequestScoped // Ensures this resource is managed per HTTP request
@Produces(MediaType.APPLICATION_JSON) // Outputs JSON response
@Consumes(MediaType.APPLICATION_JSON) // Accepts JSON request body
public class ProductResource {

    @PersistenceContext
    private EntityManager entityManager; // EntityManager for JPA transactions

    private ProductDAO productDAO;

    // Dependency Injection: CDI will inject ProductDAO
    @Inject
    public void setProductDAO(ProductDAO productDAO) {
        this.productDAO = productDAO;
    }

    // GET /api/products -> Retrieves all products
    @GET
    public List<Product> getAllProducts() {
        return productDAO.findAll();
    }

    // GET /api/products/{id} -> Retrieves a single product by ID
    @GET
    @Path("/{id}")
    public Response getProductById(@PathParam("id") Long id) {
        Product product = productDAO.findById(id);
        if (product == null) {
            return Response.status(Response.Status.NOT_FOUND).entity("Product not found").build();
        }
        return Response.ok(product).build();
    }

    // POST /api/products -> Creates a new product
    @POST
    public Response createProduct(Product product) {
        productDAO.save(product);
        return Response.status(Response.Status.CREATED).entity(product).build();
    }

    // DELETE /api/products/{id} -> Deletes a product by ID
    @DELETE
    @Path("/{id}")
    public Response deleteProduct(@PathParam("id") Long id) {
        productDAO.delete(id);
        return Response.noContent().build();
    }
}
