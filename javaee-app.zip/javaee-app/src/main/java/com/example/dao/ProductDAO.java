package com.example.dao;

import com.example.model.Product;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import java.util.List;

// Data Access Object (DAO) for managing Product entities
public class ProductDAO {
    private EntityManager entityManager;

    // Constructor to initialize the entity manager
    public ProductDAO(EntityManager entityManager) {
        this.entityManager = entityManager;
    }

    // Saves a new product to the database
    public void save(Product product) {
        entityManager.persist(product);
    }

    // Retrieves all products from the database
    public List<Product> findAll() {
        TypedQuery<Product> query = entityManager.createQuery("SELECT p FROM Product p", Product.class);
        return query.getResultList();
    }

    // Finds a product by its ID
    public Product findById(Long id) {
        return entityManager.find(Product.class, id);
    }

    // Deletes a product by ID if it exists
    public void delete(Long id) {
        Product product = findById(id);
        if (product != null) {
            entityManager.remove(product);
        }
    }
}

