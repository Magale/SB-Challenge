package com.example;

import com.example.dao.ProductDAO;
import com.example.dao.UserDAO;
import com.example.model.Product;
import com.example.model.User;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

// Unit tests for UserDAO and ProductDAO using Mockito
public class AppTest {
    private EntityManager entityManager;
    private UserDAO userDAO;
    private ProductDAO productDAO;

    // Sets up mock EntityManager and DAO instances before each test
    @BeforeEach
    public void setUp() {
        entityManager = mock(EntityManager.class);
        userDAO = new UserDAO(entityManager);
        productDAO = new ProductDAO(entityManager);
    }

    // Tests finding a user by ID
    @Test
    public void testFindUserById() {
        User user = new User();
        user.setId(1L);
        user.setName("John Doe");

        when(entityManager.find(User.class, 1L)).thenReturn(user);

        User foundUser = userDAO.findUserById(1L);

        assertNotNull(foundUser);
        assertEquals("John Doe", foundUser.getName());
    }

    // Tests retrieving all users
    @Test
    public void testFindAllUsers() {
        TypedQuery<User> query = mock(TypedQuery.class);
        List<User> users = Arrays.asList(new User("Alice"), new User("Bob"));

        when(entityManager.createQuery("SELECT u FROM User u", User.class)).thenReturn(query);
        when(query.getResultList()).thenReturn(users);

        List<User> result = userDAO.findAllUsers();

        assertNotNull(result);
        assertEquals(2, result.size());
    }

    // Tests finding a product by ID
    @Test
    public void testFindProductById() {
        Product product = new Product("Laptop", 1200.0);
        product.setId(1L);

        when(entityManager.find(Product.class, 1L)).thenReturn(product);

        Product foundProduct = productDAO.findById(1L);

        assertNotNull(foundProduct);
        assertEquals("Laptop", foundProduct.getName());
    }

    // Tests retrieving all products
    @Test
    public void testFindAllProducts() {
        TypedQuery<Product> query = mock(TypedQuery.class);
        List<Product> products = Arrays.asList(new Product("Phone", 700.0), new Product("Tablet", 300.0));

        when(entityManager.createQuery("SELECT p FROM Product p", Product.class)).thenReturn(query);
        when(query.getResultList()).thenReturn(products);

        List<Product> result = productDAO.findAll();

        assertNotNull(result);
        assertEquals(2, result.size());
    }
}
