package com.example;

import com.example.dao.UserDAO;
import com.example.model.User;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

class AppTest {

    private EntityManager entityManager;
    private TypedQuery<User> typedQuery;
    private UserDAO userDAO;

    @BeforeEach
    void setUp() {
        // Create mock objects for EntityManager and TypedQuery
        entityManager = mock(EntityManager.class);
        typedQuery = mock(TypedQuery.class);

        // Initialize UserDAO with the mocked EntityManager
        userDAO = new UserDAO(entityManager);
    }

    @Test
    void testFindUserByEmail() {
        String email = "test@example.com"; // Sample email
        
        // Mock the behavior of the EntityManager's createQuery method
        when(entityManager.createQuery("SELECT u FROM User u WHERE u.email = :email", User.class)).thenReturn(typedQuery);
        
        // Mock the setParameter method on TypedQuery
        when(typedQuery.setParameter("email", email)).thenReturn(typedQuery);
        
        // Mock the getSingleResult method to return a mock User object
        User mockUser = new User();
        mockUser.setEmail(email); // Assuming a setEmail method exists in the User class
        when(typedQuery.getSingleResult()).thenReturn(mockUser);

        // Call the method to test
        User user = userDAO.findUserByEmail(email);

        // Verify that the result is not null
        assertNotNull(user);
        assertEquals(email, user.getEmail());  // Assuming User has getEmail() method

        // Verify that the createQuery and setParameter methods were called
        verify(entityManager).createQuery("SELECT u FROM User u WHERE u.email = :email", User.class);
        verify(typedQuery).setParameter("email", email);
        verify(typedQuery).getSingleResult();
    }
}
