package com.example.dao;

import com.example.model.User;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import jakarta.persistence.NoResultException;
import java.util.List;

public class UserDAO {
    private EntityManager entityManager;

    // Constructor to initialize EntityManager
    public UserDAO(EntityManager entityManager) {
        this.entityManager = entityManager;
    }

    // Save a user to the database
    public void saveUser(User user) {
        entityManager.persist(user);
    }

    // Find all users in the database
    public List<User> findAllUsers() {
        TypedQuery<User> query = entityManager.createQuery("SELECT u FROM User u", User.class);
        return query.getResultList();
    }

    // Find a user by their ID
    public User findUserById(Long id) {
        return entityManager.find(User.class, id);
    }

    // Find a user by their email address, handling the NoResultException if no user is found
    public User findUserByEmail(String email) {
        try {
            TypedQuery<User> query = entityManager.createQuery("SELECT u FROM User u WHERE u.email = :email", User.class);
            query.setParameter("email", email);
            return query.getSingleResult();  // Will return a single result or throw NoResultException if not found
        } catch (NoResultException e) {
            return null;  // Return null if no user is found with the given email
        }
    }

    // Update a user in the database
    public void updateUser(User user) {
        entityManager.merge(user);
    }

    // Delete a user by their ID
    public void deleteUser(Long id) {
        User user = findUserById(id);
        if (user != null) {
            entityManager.remove(user);
        }
    }
}
